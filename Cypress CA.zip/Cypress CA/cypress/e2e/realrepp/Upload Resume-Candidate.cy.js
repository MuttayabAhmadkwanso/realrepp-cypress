describe('File upload and save test', () => {
 it('should upload a file and save', () => {


   //Login Module
   cy.visit('https://stage.ats.realrepp.com/')
   cy.get('#email').type('petertan@realrepp.com')
   cy.get('#password').type('petertan@realrepp.com')
   cy.get('.btn').click()
   cy.get('.hamburger').click() // Open side menu

   cy.visit('https://stage.ats.realrepp.com/candidates?currentPage=1&filterCheck=true&limit=10')
   cy.get('#nameSearch').type('Alisha khan')
   cy.wait(6000);
   cy.get(':nth-child(1) > :nth-child(1) > .d-flex > .ml-3 > .route-link').click()


   cy.get('.CandidateTabsWrapper > :nth-child(1) > :nth-child(2) > .nav-link').click()
   cy.get('.CandidateTabsWrapper > :nth-child(2) > :nth-child(2) > :nth-child(1) > .d-flex > :nth-child(1)').click()

   cy.fixture('231-student-resume.docx', 'binary').then(fileContent => {
    // Convert the binary file content to a Blob
    const blob = Cypress.Blob.binaryStringToBlob(fileContent);
  
    // Create a File object from the Blob
    const file = new File([blob], '231-student-resume.docx', { type: 'application/msword' });
  
    // Use JavaScript to set the value of the file input
    cy.get('input[type="file"]').then(subject => {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      subject[0].files = dataTransfer.files;
      // Trigger a change event to simulate user interaction
      subject[0].dispatchEvent(new Event('change', { bubbles: true }));
    });
    cy.wait(6000);
    cy.get('.big-width').click();

    cy.wait(5000);
  });
  
 });

});