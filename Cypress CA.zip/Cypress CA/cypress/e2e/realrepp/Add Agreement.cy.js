it.only('Add Agreeement', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click();

    //  Open side menu
      cy.get('.hamburger').click(); // Open side menu


     //Agreement listing page
     cy.get(':nth-child(3) > .d-flex > a').click();
     cy.get('.filter-select > :nth-child(2) > :nth-child(2)').click();
     cy.get('.css-1hwfws3').click().wait(3000).type('{downarrow}{downarrow}{enter}');
     cy.get(':nth-child(3) > .col-sm-12 > .form-group > .form-control').select('ADEEL NAQVI');
     cy.get('#nickName').type('Test Agreement');
     cy.get('.agreementLabel > .row > :nth-child(1) > .form-group > .form-control').select('25 %');
     cy.get(':nth-child(2) > .form-group > .form-control').select('30 days');
     cy.get(':nth-child(3) > .form-group > .form-control').select('30 days');
     cy.get('.big-width').click();

})