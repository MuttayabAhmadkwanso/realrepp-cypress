it.only('Update Company', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()



    //  Open side menu
    cy.get('.hamburger').click() // Open side menu

    //companies listing page
     cy.visit ('https://stage.ats.realrepp.com/companies?currentPage=1&limit=10')


     cy.get('#companySearch').type('Muttayab company');
     cy.get(':nth-child(1) > .route-link').click();
    

     //Address Tab
     cy.get(':nth-child(5) > .nav-link').click();
     cy.get('.user-basic-form > :nth-child(1) > .d-flex > .buttonGenericStyle').click();
     cy.get('#streetAddress').type('Address');
     cy.get('#city').click().type('Tampa');
     cy.get('.col-xl-4 > .undefined > .form-control').select('Florida');
     cy.get('.address-action > .btn').click();
     cy.wait(5000);

     //Add Company Contacts
     cy.get(':nth-child(7) > .nav-link').click();
     cy.get('.card-inner-padding > .buttonGenericStyle').click();
     cy.get('#firstName').type('Muttayab');
     cy.get('#lastName').type('Test');
     cy.get('#jobTitle').type('SQA Engineer');
     cy.get(':nth-child(4) > .undefined > .form-control').select('LinkedIn Application');
     cy.get('.col-lg-12 > :nth-child(1) > .d-flex-field > .d-flex > :nth-child(1) > .mb-0 > .form-control').type('muttayab.ahmad+ccc1@kwanso.com');
     cy.get('.modal-footer > .btn').click();
     cy.wait(5000);

     //Add Company Summary
     cy.get('.dropdown-toggle').click();
     cy.get('.dropdown-menu > .cursor-pointer').click();
     cy.get(':nth-child(10) > .form-group > .editor-height > .quill > .ql-container > .ql-editor').type('test test test test test test test test test test test test');
     cy.get('.big-width').click();
     cy.wait(5000);

})