it.only('Add Owner & Sharee', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()



    //  Open side menu
    cy.get('.hamburger').click() // Open side menu

    //companies listing page
     cy.visit ('https://stage.ats.realrepp.com/companies?currentPage=1&limit=10')


     cy.get('#companySearch').type('Muttayab company');
     cy.get(':nth-child(1) > .route-link').click();
     cy.get('.dropdown-toggle').click();
     cy.get('.dropdown-menu > .cursor-pointer').click();

    //Owners & sharee Tab
     cy.get('.CandidateTabsWrapper > :nth-child(1) > :nth-child(3) > .nav-link').click();
     cy.get('.user-basic-form > .d-flex > .buttonGenericStyle').click();
     cy.get('.modal-body > :nth-child(2) > .form-control').select('Peter Tan');
     cy.get('.big-width').click();


})