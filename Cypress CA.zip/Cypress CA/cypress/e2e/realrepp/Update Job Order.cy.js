
it('Update Job Order', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()


    cy.get('.hamburger').click() // Open side menu

    cy.visit('https://stage.ats.realrepp.com/update-job-order/f3bd4569-c358-4f97-9fd6-f604eefd65dd')

    //  ---- job Ad Details tab ----

    cy.get(':nth-child(2) > .nav-link').click()
    cy.get('.big-width').click()

    // ---- advertised job tab ---

    cy.get(':nth-child(3) > .nav-link').click() //advertised location tab
    cy.get('.jobOrdersActionLog > .jobOrderRevamp > .buttonGenericStyle').click()
    cy.get('#city').type('America')
    cy.get(':nth-child(2) > .undefined > .form-control').select('Florida')
    cy.get('.address-action > .buttonGenericStyle').click()
    cy.wait(5000);



    // ----Assigned recruiters -----

    cy.get(':nth-child(4) > .nav-link').click()
    cy.get('.css-1t7n4nw-container > .css-onzmuj-control > .css-1hwfws3').click().wait(5000).type('{downarrow}{enter}');
    cy.wait(5000);
    cy.get('.user-basic-form > :nth-child(1) > .justify-content-end > .buttonGenericStyle').click()
    cy.wait(5000);


    //  ---- Documents tab  ----
    cy.get(':nth-child(5) > .nav-link').click()
    cy.get('.user-basic-form > .jobOrderRevamp > .buttonGenericStyle').click()
    cy.get('.custom-file-upload > input').click()
    cy.get('input[type=file]').selectFile({
        contents: Cypress.Buffer.from('file contents'),
        fileName: 'Downloads/Canada.pdf',
    })
    cy.get('.big-width').click()
    cy.wait(5000);


    //  --- Job Applicants tab -----
    cy.get(':nth-child(6) > .nav-link').click({force:true}) //job applicants tab


    // ---- company documents tab ----
    cy.get(':nth-child(7) > .nav-link').click()
    cy.get('.resumeHeader > .buttonGenericStyle').click()
    cy.get('.custom-file-upload > input').click()
    cy.get('input[type=file]').selectFile({
        contents: Cypress.Buffer.from('file contents'),
        fileName: 'Downloads/Canada.pdf',
    })
    cy.get('.mt-3 > .btn').click()
    cy.wait(5000);


// ------ Submission tab ------
    cy.get(':nth-child(8) > .nav-link').click() //submission tab
    cy.wait(5000);


})