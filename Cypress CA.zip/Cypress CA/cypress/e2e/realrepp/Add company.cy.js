
import { LoginTest } from './Login Page.cy';


it.only('Add Company', () => {

    //Login Module
    LoginTest();


    //  Open side menu
      cy.get('.hamburger').click() // Open side menu


      //companies listing page
       cy.visit ('https://stage.ats.realrepp.com/companies?currentPage=1&limit=10')


      //Open Add companies page 
      cy.get('.primaryHeaderSpacing > .mr-3').click()

      cy.get('#name').type('Muttayab Company')
      cy.get(':nth-child(4) > .form-control').type('https://www.google.com')
      cy.get(':nth-child(8) > .form-control').type('https://www.yahoo.com')
      cy.get(':nth-child(10) > .form-group > .form-control').type('test source note')
      cy.get('#streetAddress').type('House no 111')
      cy.get('#city').type('England')
      cy.get('.col-xl-4 > .undefined > .form-control').type('state')
      cy.get('.col-xl-6 > .undefined > .form-control').type('country')
      cy.get('.linkedin-form-container > .ml-3 > label > .form-check-input').check() //checkmark linkedin field
      cy.get(':nth-child(9) > .undefined > .form-control').select('Twitter') // select source from dropdown list
      cy.get('.col-xl-4 > .undefined > .form-control').select('Hawaii') // select state from dropdown list
      cy.get('.big-width').click()   // click add company button
      cy.wait(5000);

})