it ('candidate submission', () => {
   
      
    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()
    cy.get('.hamburger').click() // Open side menu



    // Candidates listing page

   cy.visit('https://stage.ats.realrepp.com/candidates?currentPage=1&filterCheck=true&limit=10')
   
   cy.get('#nameSearch').type('Muttayab Test')
   cy.wait(7000);
   cy.get(':nth-child(1) > :nth-child(1) > .d-flex > .ml-3 > .route-link').click()

   
   //candidate submission
   cy.get('.actionsDropdown > .dropdown-toggle').click()
   cy.get('.dropdown-menu > :nth-child(3)').click()
   cy.get('.css-onzmuj-control > .css-1hwfws3').click().wait(10000).type('{downarrow}{enter}');
   cy.wait(20000);
   cy.get('.select__value-container').click().wait(5000).type('{downarrow}'.repeat(9)+'{enter}');
   cy.get('.text-right > .btn').click();
   cy.wait(15000);

   //Add submission Detail
   cy.get('.w-100 > .form-control').type('5000');
   cy.get('.form-group > .css-1t7n4nw-container > .css-onzmuj-control > .css-1hwfws3').click().wait(7000).type('{downarrow}{enter}');
   cy.get('.big-width').click();
   cy.get(':nth-child(2) > .text-right > .buttonGenericStyle').click();
   cy.wait(23000);
   

   //Schedule Interview
   cy.get(':nth-child(8) > .nav-link').click().wait(5000);
   cy.get(':nth-child(2) > .mb-4 > .status-main > .status-3 > .customMenuDropdown > .dropdown-toggle').click();
   cy.get(':nth-child(2) > .mb-4 > .status-main > .status-3 > .customMenuDropdown > .dropdown-menu > .color-grey').click();
   cy.get(':nth-child(1) > .css-198krsd-container > .css-onzmuj-control > .css-1hwfws3').click().wait(5000).type('{downarrow}{enter}');
   cy.get(':nth-child(3) > .css-198krsd-container > .css-onzmuj-control').click().wait(5000).type('{downarrow}{downarrow}{enter}');
   cy.get('.ql-editor').type('Test');
   cy.get('form > .d-flex > .btn').click().wait(5000);
   cy.wait(15000);

   
   //Convert to Offer
   cy.get(':nth-child(2) > .mb-4 > .status-main > .status-3 > .customMenuDropdown > .dropdown-toggle').click();
   cy.get(':nth-child(2) > .mb-4 > .status-main > .status-3 > .customMenuDropdown > .dropdown-menu > :nth-child(3)').click();
   cy.get('.pl-2').type('20');
   cy.get('.pb-3.col-lg-12 > .form-control').click().type('2023-12-13');
   cy.get('#details').type('Test');
   cy.get('.big-width').click();
   cy.wait(15000);

   //Move to Placement
   cy.get('.status-3 > .customMenuDropdown > .dropdown-toggle').click();
   cy.get('.customMenuDropdown > .dropdown-menu > :nth-child(2)').click();
   cy.wait(10000);

})