it ('Add candidate', () => {
   
      
    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()
    cy.get('.hamburger').click() // Open side menu



   // Candidates listing page

   cy.visit('https://stage.ats.realrepp.com/candidates?currentPage=1&filterCheck=true&limit=10')
   
   // Add candidate 
   cy.get('.mobileResponsiveFlex > .buttonGenericStyle').click()
   cy.get('#firstName').type('Alisha')
   cy.get('#lastName').type('Khan')
   cy.get('.css-1hwfws3').click()
   cy.get('#react-select-2-option-0').click()
   cy.get('.text-left > .form-control').type('muttayab.ahmad+cyca1@kwanso.com')
   cy.get('.mb-0 > .form-control').type('333-4343')
   cy.get('#streetAddress').type('444')
   cy.get('#city').type ('Houston')
   cy.get('.col-xl-4 > .undefined > .form-control').select('Florida')
   cy.get('#zipCode').type ('777')
   cy.get('#linkedInUrl').type('https://www.linkedin.com/')
   cy.get('.big-width').click()  

})