it.only('Add Contact', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()

    //  Open side menu
      cy.get('.hamburger').click() // Open side menu


      //contact listing page
      cy.get(':nth-child(2) > .d-flex > a').click();
      cy.get('.filter-select > .mr-3').click();
      cy.get('#firstName').type('Muttayab');
      cy.get('#lastName').type('Test');
      cy.get('#jobTitle').type('SQA Engineer');
      cy.get(':nth-child(4) > .undefined > .form-control').select('LinkedIn Search');
      cy.get(':nth-child(5) > .d-flex > .bg-transparent').click();
      cy.wait(2000);
      cy.get('#name').type('Muttayab Company');
      cy.get(':nth-child(4) > .ml-3 > .m-0 > .mt-1').click();
      cy.get(':nth-child(8) > .ml-3 > .m-0 > .mt-1').click();
      cy.get(':nth-child(9) > .undefined > .form-control').select('LinkedIn Search');
      cy.get(':nth-child(10) > .form-group > .form-control').type('Test');
      cy.get('#city').type('Tampa');
      cy.get('.col-xl-4 > .undefined > .form-control').select('Florida');
      cy.get('.linkedin-form-container > .ml-3 > label > .form-check-input').click();
      cy.get('.modal-footer > .btn').click();
      cy.get('.col-lg-12 > :nth-child(1) > .d-flex-field > .d-flex > :nth-child(1) > .mb-0 > .form-control').type('muttayab.ahmad+ccc1@kwanso.com');
      cy.get('.big-width').click();


})