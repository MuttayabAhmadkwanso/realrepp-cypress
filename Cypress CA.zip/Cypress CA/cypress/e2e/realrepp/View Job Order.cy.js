it  ('View Job order' , () => {


//Login Module
cy.visit('https://stage.ats.realrepp.com/')
cy.get('#email').type('petertan@realrepp.com')
cy.get('#password').type('petertan@realrepp.com')
cy.get('.btn').click()


cy.get('.hamburger').click() // Open side menu
cy.get(':nth-child(4) > .d-flex > a').click()
cy.get(':nth-child(1) > :nth-child(8) > .d-flex > a.iconButtonAction > img').click()


})