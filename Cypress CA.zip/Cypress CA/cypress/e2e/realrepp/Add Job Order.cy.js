it('Add Job Order ', () => {

    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()


    //   Open side menu

    cy.get('.hamburger').click() // Open side menu
    cy.get(':nth-child(4) > .d-flex > a').click()
    cy.get('.filter-status > .buttonGenericStyle').click() // Open add job order page
    cy.get('.row > :nth-child(1) > .form-control').type('Senior Test Engineer')
    cy.get('.row > :nth-child(2) > .form-control').type('Advertised test engineer job')
    cy.get('.css-1t2f22x-control > .css-1hwfws3').type('Intel')
    cy.get('#react-select-3-option-0').click()
    cy.get('.m-0 > .css-198krsd-container > .css-onzmuj-control > .css-1hwfws3').first().click()
    cy.get('#react-select-4-option-2').first().click()
    cy.get(':nth-child(5) > .mb-0 > .css-198krsd-container > .css-onzmuj-control > .css-1hwfws3').click()
    cy.get('#react-select-5-option-0').click()
    cy.get(':nth-child(6) > .mb-0 > .css-198krsd-container > .css-onzmuj-control > .css-1hwfws3').click()
    cy.get('#react-select-6-option-2').click()
    cy.get('.mb-2 > :nth-child(2) > .user-basic-form > .row > :nth-child(7) > .form-group > .css-198krsd-container > .css-onzmuj-control > .css-1hwfws3').click()
    cy.get('#react-select-7-option-4').click ()
    cy.get(':nth-child(12) > .form-group > .form-control').clear()
    cy.get(':nth-child(12) > .form-group > .form-control').type('10')
    cy.get('.ql-editor').type ('test info')
    cy.get('.big-width').click()
    cy.wait(5000);

})