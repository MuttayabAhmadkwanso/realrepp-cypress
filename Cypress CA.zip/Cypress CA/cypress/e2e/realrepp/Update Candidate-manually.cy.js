it ('Update candidate', () => {
   
      
    //Login Module
    cy.visit('https://stage.ats.realrepp.com/')
    cy.get('#email').type('petertan@realrepp.com')
    cy.get('#password').type('petertan@realrepp.com')
    cy.get('.btn').click()
    cy.get('.hamburger').click() // Open side menu



   // Candidates listing page

   cy.visit('https://stage.ats.realrepp.com/candidates?currentPage=1&filterCheck=true&limit=10')
   
   // Add candidate 
   cy.get('.mobileResponsiveFlex > .buttonGenericStyle').click()
   cy.get('#firstName').type('Muttayab')
   cy.get('#lastName').type('Test')
   cy.get('.css-1hwfws3').click()
   cy.get('#react-select-2-option-0').click()
   cy.get('.mb-0 > .form-control').type('333-4343')
   cy.get('.text-left > .form-control').type('muttayab.ahmad+cyca1@kwanso.com')
   cy.get('#streetAddress').type('444')
   cy.get('#city').type ('Houston')
   cy.get('.col-xl-4 > .undefined > .form-control').select('Florida')
   cy.get('#zipCode').type ('777')
   cy.get('#linkedInUrl').type('https://www.linkedin.com/')
   cy.get('.big-width').click()
   cy.wait(5000);

   cy.get('.hamburger').click() // Open side menu
   cy.visit('https://stage.ats.realrepp.com/candidates?currentPage=1&filterCheck=true&limit=10')
   cy.get('#nameSearch').type('Muttayab Test')
   cy.wait(5000);
   cy.get(':nth-child(1) > :nth-child(1) > .d-flex > .ml-3 > .route-link').click()


   cy.get('.CandidateTabsWrapper > :nth-child(1) > :nth-child(2) > .nav-link').click()
   cy.get('.CandidateTabsWrapper > :nth-child(2) > :nth-child(2) > :nth-child(1) > .d-flex > :nth-child(1)').click()

   cy.fixture('231-student-resume.docx', 'binary').then(fileContent => {
    // Convert the binary file content to a Blob
    const blob = Cypress.Blob.binaryStringToBlob(fileContent);
  
    // Create a File object from the Blob
    const file = new File([blob], '231-student-resume.docx', { type: 'application/msword' });
  
    // Use JavaScript to set the value of the file input
    cy.get('input[type="file"]').then(subject => {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      subject[0].files = dataTransfer.files;
      // Trigger a change event to simulate user interaction
      subject[0].dispatchEvent(new Event('change', { bubbles: true }));
    });
    cy.wait(5000);
    cy.get('.big-width').click();

    cy.wait(40000);
  });
  

   //Add Candidate Notes (phone call)
   cy.get(':nth-child(5) > .edit-candidate').click()
   cy.get('form > :nth-child(1) > .css-198krsd-container > .css-gwb582-control > .css-1hwfws3').click().type('{downarrow}'.repeat(15)+'{enter}');
   cy.get('.ql-editor').type('Test')
   cy.get('form > .text-right > .buttonGenericStyle').click();

   cy.wait(5000);
   
   //Add Candidate Notes (internal web interview )
   cy.get(':nth-child(5) > .edit-candidate').click()
   cy.get('form > :nth-child(1) > .css-198krsd-container > .css-gwb582-control > .css-1hwfws3').click().type('{downarrow}'.repeat(8)+'{enter}');
   cy.get('.ql-editor').type('Test')
   cy.get('form > .text-right > .buttonGenericStyle').click();
   
   cy.wait(5000);

   //Add New Writeup/summary
   cy.get('.CandidateTabsWrapper > :nth-child(1) > :nth-child(4) > .nav-link').click()
   cy.get('.candidate-action > .btn').click()
   cy.get('.ql-editor').type('Test')
   cy.get('.p-0 > .justify-content-end > .btn').click();


})
