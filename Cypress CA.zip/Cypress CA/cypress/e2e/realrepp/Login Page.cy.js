export function LoginTest() {

     //Login Module
     cy.visit('https://stage.ats.realrepp.com/')
     cy.get('#email').type('petertan@realrepp.com')
     cy.get('#password').type('petertan@realrepp.com')
     cy.get('.btn').click()

}
