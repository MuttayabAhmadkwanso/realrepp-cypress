describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://app.collegeadvisor.com')
 
    cy.get(':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input').type('muttayab.ahmad+ps3@kwanso.com');
    
    cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');

    cy.contains('Login').click();

  })
})
