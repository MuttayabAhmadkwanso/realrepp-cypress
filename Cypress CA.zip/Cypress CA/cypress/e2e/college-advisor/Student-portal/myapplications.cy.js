describe('Example Test Suite', () => {
    before(() => {
      // Add a handler for the uncaught:exception event
      Cypress.on('uncaught:exception', (err, runnable) => {
        // Check if the error message contains the specific text you want to handle
        if (err.message.includes('"userRole" violates unique constraint')) {
          // This error is expected, so don't fail the test
          return false;
        }
      });
    });
  
    it('should handle unique constraint violation gracefully', () => {
      // Trigger the application code that causes the error
      // For example, trying to create a duplicate "userRole"
    });
  });

describe('template spec', () => {
    it('passes', () => {

      cy.visit('https://app.collegeadvisor.com')
   
      cy.get(':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input').type('muttayab.ahmad+ps3@kwanso.com');
      
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');
  
      cy.contains('Login').click();

      cy.wait(4000);

      cy.get('[href="/applications"]', { timeout: 20000 }).should('be.visible').click();

      cy.contains('Add Colleges').click();

      cy.get('[placeholder="Search Colleges"]').type('Rice University');

      cy.wait(4000);

      cy.contains('Add to my Colleges').click({force:true});

      cy.contains('Add to my Colleges').click({force:true});

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiButtonBase-root > .MuiIconButton-label > img').click();

      cy.wait(4000);

      cy.get('.MuiList-root > :nth-child(1)').click();

      cy.wait(4000);

      cy.get('[href="/colleges/4021"] > .MuiButtonBase-root > .MuiButton-label').click();

      cy.wait(4000);

      cy.get('.MuiIconButton-label > img').click();

      cy.wait(4000);

      cy.get('.MuiIconButton-label > img').click();

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiButtonBase-root > .MuiIconButton-label > img').click();

      cy.wait(4000);
     
      cy.get('.MuiList-root > :nth-child(3)').click({force:true});

      cy.wait(4000);

      cy.get('.MuiDialogActions-root').contains('Delete').click({force:true});

      cy.wait(4000);

  
    })
  })
  