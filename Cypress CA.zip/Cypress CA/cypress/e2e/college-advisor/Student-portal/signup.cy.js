describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://app.collegeadvisor.com')
   
      cy.get('#go-to-signup').click();

      cy.get(':nth-child(2) > .jss216 > .MuiInputBase-root > .MuiInputBase-input').type('Muttayab');

      cy.get(':nth-child(2) > :nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('Test');

      const randomNumber = Math.floor(Math.random() * 1000);

      const newEmail = `muttayab.ahmad+tss${randomNumber}@kwanso.com`;

      cy.get(':nth-child(3) > .MuiInputBase-root > .MuiInputBase-input').type(newEmail);

      cy.get('.jss472 > .MuiBox-root > .PhoneInput > .PhoneInputCountry > .PhoneInputCountrySelect').select('Pakistan');

      cy.get('.jss472 > .MuiBox-root > .PhoneInput > .PhoneInputInput').type('3174959984');

      cy.get('#mui-component-select-year').click();

      cy.get('[data-value="2025"]').click();

      cy.get(':nth-child(8) > .jss216 > .MuiInputBase-root > .MuiInputBase-input').type('Muttayab');

      cy.get(':nth-child(8) > :nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('Test');

      const randomNumber1 = Math.floor(Math.random() * 1000);

      const newEmail1 = `muttayab.ahmad+tss${randomNumber1}@kwanso.com`;

      cy.get(':nth-child(9) > .MuiInputBase-root > .MuiInputBase-input').type(newEmail1);

      cy.get('.jss483 > .MuiBox-root > .PhoneInput > .PhoneInputCountry > .PhoneInputCountrySelect').select('Pakistan');

      cy.get('.jss483 > .MuiBox-root > .PhoneInput > .PhoneInputInput').type('3174959985');

      cy.get(':nth-child(5) > .MuiTypography-root').click();

      cy.get('.MuiButton-label-493').click();

      cy.get('.jss214 > .MuiGrid-root > :nth-child(1) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');

      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');

      cy.get('.MuiButton-label-738').click();
  
    })
  })

