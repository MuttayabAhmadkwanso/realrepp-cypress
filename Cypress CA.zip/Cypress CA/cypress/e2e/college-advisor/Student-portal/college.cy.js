describe('Example Test Suite', () => {
    before(() => {
      // Add a handler for the uncaught:exception event
      Cypress.on('uncaught:exception', (err, runnable) => {
        // Check if the error message contains the specific text you want to handle
        if (err.message.includes('"userRole" violates unique constraint')) {
          // This error is expected, so don't fail the test
          return false;
        }
      });
    });
  
    it('should handle unique constraint violation gracefully', () => {
      // Trigger the application code that causes the error
      // For example, trying to create a duplicate "userRole"
    });
  });


describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://app.collegeadvisor.com')
   
      cy.get(':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input').type('muttayab.ahmad+ps3@kwanso.com');
      
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');
  
      cy.contains('Login').click();

      cy.wait(7000);

      cy.get('[href="/colleges"]').click();

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(4000);

      cy.contains('Acceptance Rate (High to Low)').click();

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(2000);

      cy.contains('Tuition (High to Low)').click();

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(2000);

      cy.contains('Tuition (Low to High)').click();

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(2000);

      cy.contains('Alphabetical (A -> Z)').click({force:true});

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(2000);

      cy.contains('Alphabetical (Z -> A)').click({force:true});

      cy.wait(4000);

      cy.get('.MuiBox-root > .MuiGrid-root > .customDropDown > .select__control').click();

      cy.wait(2000);

      cy.contains('Acceptance Rate (High to Low)').click();

      cy.wait(4000);

      cy.get('#panel1a-content > .MuiAccordionDetails-root > .MuiGrid-root > .customDropDown > .select__control').type('Harvard University');

      cy.wait(7000);

      cy.contains('Add To My Applications').click({force:true});

      cy.wait(4000);

      cy.get('button').contains('Start').click();

      cy.wait(4000);

      cy.get('a > .MuiTypography-root').click();

      cy.wait(10000);

      cy.get(':nth-child(7) > .MuiButtonBase-root > .MuiListItemText-root > .MuiTypography-root').click();

      cy.wait(7000);

      cy.get(':nth-child(8) > .MuiButtonBase-root > .MuiListItemText-root > .MuiTypography-root').click();

      cy.wait(7000);

      cy.contains('Added To My Applications').click({force:true});

      cy.wait(2000);

      cy.get('.MuiButtonBase-root > .MuiTypography-root').click();

      cy.wait(2000);

      cy.get('button').contains('Delete').click();

      cy.wait(2000);

      cy.get('.MuiIconButton-label > img').click();

      cy.wait(4000);

      cy.get('.clearFilter > .MuiButton-label').click();

      cy.wait(2000);

  
    })
  })
  