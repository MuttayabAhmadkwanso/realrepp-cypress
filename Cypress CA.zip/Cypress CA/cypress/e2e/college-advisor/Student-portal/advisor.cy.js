describe('Example Test Suite', () => {
    before(() => {
      // Add a handler for the uncaught:exception event
      Cypress.on('uncaught:exception', (err, runnable) => {
        // Check if the error message contains the specific text you want to handle
        if (err.message.includes('"userRole" violates unique constraint')) {
          // This error is expected, so don't fail the test
          return false;
        }
      });
    });
  
    it('should handle unique constraint violation gracefully', () => {
      // Trigger the application code that causes the error
      // For example, trying to create a duplicate "userRole"
    });
  });


describe('Advisor Direct meeting book', () => {
    it('passes', () => {
      cy.visit('https://app.collegeadvisor.com')
   
      cy.get(':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input').type('muttayab.ahmad+ps3@kwanso.com');
      
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('National$1');
  
      cy.contains('Login').click();

      cy.wait(4000);

      cy.get('[href="/advisors"]').click();

      cy.wait(4000);

      cy.get('[placeholder="Search Advisor Name or College"]').type('NYasin');

      cy.wait(4000);

      cy.contains('NYasin Advisor').click({force:true});

      cy.wait(4000);

      cy.contains('Schedule Video Chat').click({force:true});

      cy.wait(5000);

      cy.contains('4:00 PM').click({force:true});

      cy.contains('Next').click({force:true});

      cy.wait(5000);

      cy.contains('Confirm Meeting').click({force:true});

      cy.wait(5000);

      cy.visit('https://app.collegeadvisor.com/home')

      cy.wait(5000);

      cy.get('button').eq(1).click();

      cy.wait(5000);

      cy.contains('CANCEL MEETING').click({force:true});

      cy.wait(5000);

      cy.contains('Cancel Meeting').click({force:true});
      
    })
  })
  