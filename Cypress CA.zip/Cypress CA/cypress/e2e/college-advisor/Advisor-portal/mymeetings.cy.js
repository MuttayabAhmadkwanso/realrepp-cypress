describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://advisors.collegeadvisor.com/')
   
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
      
      cy.get(':nth-child(3) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
  
      cy.get('form > .MuiButtonBase-root > .MuiButton-label').click();

      cy.wait(3000);

      cy.get('#simple-tab-1 > .MuiTab-wrapper').click();

      cy.wait(3000);

      cy.get('.MuiInputBase-input').type('Test');

      cy.wait(3000);

      cy.get('#simple-tab-2 > .MuiTab-wrapper').click();

      cy.wait(3000);

      cy.get('#simple-tab-0 > .MuiTab-wrapper').click();

  
    })
  })


  