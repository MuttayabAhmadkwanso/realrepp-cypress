describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://advisors.collegeadvisor.com/')
   
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
      
      cy.get(':nth-child(3) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
  
      cy.get('form > .MuiButtonBase-root > .MuiButton-label').click();

      cy.wait(3000);

      cy.get('.main-nav > :nth-child(3) > a').click();

      cy.wait(3000);

      cy.contains('Today').click();

      cy.wait(3000);

      cy.contains('ADD NEW OPENING').click();

      cy.wait(3000);

      cy.get('[aria-describedby="delete-popover"]').eq(1).click({force:true});

      cy.wait(7000);

      cy.get(':nth-child(3) > .MuiIconButton-label > img').click();

      cy.wait(3000);

      cy.contains('Set recurrence to every Wednesday until').click({force:true});

      cy.wait(3000);

      cy.get('[aria-describedby="delete-popover"]').eq(1).click({force:true});

      cy.wait(3000);

      cy.get(':nth-child(4) > .MuiIconButton-label > img').eq(1).click();


      //cy.get('.').find('button').click();

      //cy.get('span.MuiTouchRipple-root').click();

      //cy.get('img').should('have.attr', 'alt').click({force:true});

  
    })
  })
