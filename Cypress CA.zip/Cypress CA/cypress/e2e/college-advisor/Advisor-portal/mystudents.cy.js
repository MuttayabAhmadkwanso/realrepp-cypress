describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://advisors.collegeadvisor.com/')
   
      cy.get(':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
      
      cy.get(':nth-child(3) > .MuiInputBase-root > .MuiInputBase-input').type('nyasin@joincollegeadvisor.com');
  
      cy.get('form > .MuiButtonBase-root > .MuiButton-label').click();

      cy.wait(3000);

      cy.get('.main-nav > :nth-child(2) > a').click();

      cy.wait(3000);

      cy.get(':nth-child(2) > .MuiButton-label').click();

      cy.wait(3000);

      cy.get(':nth-child(3) > .MuiButton-label').click();

      cy.wait(3000);

      cy.get(':nth-child(4) > .MuiButton-label').click();

      cy.wait(3000);

      cy.get(':nth-child(1) > .MuiButton-label').click();

      cy.wait(3000);

      cy.get('[placeholder="Search Students"]').type('Muttayab Test');

      cy.wait(3000);

      cy.get(':nth-child(1) > :nth-child(5) > img').click();

      cy.wait(3000);

      cy.contains('5:00 PM').click();

      cy.contains('Next').click();

      cy.wait(3000);

      cy.contains('Confirm Meeting').click();

      cy.wait(3000);

      cy.get('.MuiIconButton-label > img').click({force:true});

      cy.wait(3000);

      cy.get('.main-nav > :nth-child(1) > a').click();

      cy.wait(3000);

      cy.get('.MuiIconButton-label > img').click();

      cy.wait(3000);

      cy.get('.react-select__value-container').click();

      cy.wait(3000);

      cy.contains('Other').click();

      cy.wait(3000);

      cy.get('[rows="3"]').type('Test');

      cy.wait(3000);

      cy.get('.MuiButton-contained > .MuiButton-label').click({force:true});

  
    })
  })
